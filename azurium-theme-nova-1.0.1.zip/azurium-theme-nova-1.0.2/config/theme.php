<?php

return [
    'server_name'       => theme_config('server_name', site_name()),
    'hero_title'        => theme_config('hero_title', 'Welcome to our server'),
    'hero_subtitle'     => theme_config('hero_subtitle', 'A modern Azuriom theme inspired by Nova.'),
    'hero_button_text'  => theme_config('hero_button_text', 'Start now'),
    'hero_button_link'  => theme_config('hero_button_link', '/shop'),
    'discord_link'      => theme_config('discord_link', 'https://discord.gg/example'),
    'background_image'  => theme_config('background_image', 'img/hero-bg.jpg'),
    'server_ip'         => theme_config('server_ip', 'play.example.com'),
    'server_ip2'        => theme_config('server_ip2', ''),
    'server_ip3'        => theme_config('server_ip3', ''),
    'youtube_link'      => theme_config('youtube_link', ''),
    'twitter_link'      => theme_config('twitter_link', ''),
    'github_link'       => theme_config('github_link', ''),
];
